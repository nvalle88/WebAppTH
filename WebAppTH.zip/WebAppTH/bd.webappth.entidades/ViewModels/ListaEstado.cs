﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ViewModels
{
    public class ListaEstado
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
    }
}
