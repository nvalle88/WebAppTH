﻿using bd.webappth.entidades.Negocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ViewModels
{
    public class ViewModelDeclaracionPatrimonioPersonal
    {
        public DeclaracionPatrimonioPersonal DeclaracionPatrimonioPersonal { get; set; }
        public OtroIngreso OtroIngreso { get; set; }
    }
}
