﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ViewModels
{
    public class PersonaEstudioViewModel
    {
        public string estudio { get; set; }
        public string areaConocimiento { get; set; }
        public string titulo { get; set; }
        public string fechaGraduado { get; set; }
    }
}
