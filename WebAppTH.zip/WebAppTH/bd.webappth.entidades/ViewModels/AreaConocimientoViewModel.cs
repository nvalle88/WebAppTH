﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ViewModels
{
  public class AreaConocimientoViewModel
    {
        public int IdAreaConocimiento { get; set; }
        public string Descripcion { get; set; }
        public int IdIndiceOcupacional { get; set; }
    }
}
