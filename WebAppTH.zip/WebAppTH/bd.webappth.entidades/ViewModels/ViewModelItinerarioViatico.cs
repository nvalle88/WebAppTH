﻿using bd.webappth.entidades.Negocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ViewModels
{
    public class ViewModelItinerarioViatico
    {
        public List<ItinerarioViatico> ListaItenarioViatico { get; set; }
        public int IdSolicitudViatico { get; set; }
    }
}
