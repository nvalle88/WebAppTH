﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
   public class Constantes
    {
        public const string NivelProfesional = "Profesional";
        public const string NivelNoProfesional = "No profesional";
    }
}
