﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
  public  class CapacitacioPlanificacionParametros
    {
        public int IdCapacitacionTemario { get; set; }
        public DateTime Fecha { get; set; }
    }
}
