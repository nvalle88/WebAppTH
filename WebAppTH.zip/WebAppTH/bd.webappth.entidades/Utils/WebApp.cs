﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
   public static class WebApp
    {
        public static string BaseAddress { get; set; }

        public static string BaseAddressRM { get; set; }

        public static string BaseAddressSeguridad { get; set; }

        public static string BaseAddressWebAppLogin { get; set; }

        public static string NombreAplicacion { get; set; }

    }
}
