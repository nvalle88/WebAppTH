﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
    public class PhotoRequest
    {
        public int Id { get; set; }

        public byte[] Array { get; set; }
    }
}
