﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils.Seguridad
{
    public class PermisoUsuario
    {
        public string Contexto { get; set; }
        public string Usuario { get; set; }
        public string Token { get; set; }
    }
}
