﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils.Seguridad
{
    public class UsuarioSistema
    {
        public string Usuario { get; set; }
        public string Sistema { get; set; }
    }
}
