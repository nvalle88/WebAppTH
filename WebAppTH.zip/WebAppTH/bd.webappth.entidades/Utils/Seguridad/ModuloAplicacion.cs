﻿namespace bd.webappth.entidades.Utils.Seguridad
{
    public class ModuloAplicacion
    {
        public string Path { get; set; }
        public string NombreAplicacion { get; set; }

    }
}
