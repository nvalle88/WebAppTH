﻿using System;
using System.Collections.Generic;

namespace bd.webappth.entidades.Negocio
{
    public partial class MaterialInduccion
    {
        public int IdMaterialInduccion { get; set; }
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public string Url { get; set; }
    }
}
